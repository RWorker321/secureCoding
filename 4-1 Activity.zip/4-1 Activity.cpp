// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
// Added imports
#include <stdexcept>

using namespace std;

// struct for defining custome exception called later in program
struct CustomException : std::exception
{
    const char* what() const throw() // what() returns pointer to const char
    {
        return "Custom Exception Caught";
    }
};

// References https://www.geeksforgeeks.org/exceptionbad_exception-in-c-with-examples/
bool do_even_more_custom_application_logic()
{
    // TODO: Throw any standard exception
    throw std::bad_exception(); // bad_exception returns a null terminated character that is used to identify the exception
    std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}
void do_custom_application_logic()
{
    // TODO: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing
    std::cout << "Running Custom Application Logic." << std::endl;
    try {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception &exception) {
        std::cerr << "Exception Caught: " << exception.what() << std::endl;
    }

    // TODO: Throw a custom exception derived from std::exception
    //  and catch it explictly in main
    throw CustomException(); // Throws customs exception above
    std:cerr << "\nCustom Exception Derived from std::exception Caught\n" << std::endl;
    std::cout << "Leaving Custom Application Logic." << std::endl;
}

float divide(float num, float den)
{
    // TODO: Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception
    if (den == 0) // Catches illegal divide by zero denominator exception throwing runtime error
    {
        throw std::runtime_error("Cannot divide by zero");
    }
    return (num / den);
}

void do_division() noexcept
{
    //  TODO: create an exception handler to capture ONLY the exception thrown
    //  by divide.
    float numerator = 10.0f;
    float denominator = 0;

    // Reference: https://www.tutorialspoint.com/handling-the-divide-by-zero-exception-in-cplusplus
    try
    {
        if (denominator == 0) {
            throw runtime_error("Math Error");
        }
        // Original Code Start
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
        // Original Code End
    }
    catch (runtime_error& e)
    {
        std::cerr << e.what() << std::endl;
    }
}

int main()
{
    try {
        std::cout << "Exceptions Tests!" << std::endl;
        // TODO: Create exception handlers that catch (in this order):
        //  that wraps the whole main function, and displays a message to the console.
        do_division();
        do_custom_application_logic();
    }
    //  your custom exception
    catch (CustomException& exception)  
    {
        std::cerr << exception.what() << std::endl;
    }
    //  std::exception
    catch(const std::exception &exception) 
    {
        std::cerr << exception.what() << std::endl;
    }
    //  uncaught exception 
    catch (...) // Catches all
    { 
    }
    
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu